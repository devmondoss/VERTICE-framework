# Protocolo de investigación competitiva / Deep Research — VÉRTICE v0.2

## 1. Research brief antes de buscar
Definir `pregunta de decisión`: ¿quiere renovar web, expandir segmentos, validar idea, automatizar, vender SaaS, diferenciar marketplace? Definir región, idioma, periodo, precio, segmentos primarios/secundarios, problemas/jobs y *hipótesis falsables*. No investigues a ciegas con `top 10 competitors` sin criterios.

## 2. Descubrimiento de comparables y taxonomía
**Directo:** mismo JTBD, audiencia, contexto y modalidad de oferta. **Indirecto:** mismo trabajo mediante solución distinta. **Sustituto:** método manual/offline/servicio adyacente. **Inspiracional:** patrón de experiencia de otro mercado aplicable con condiciones. **No comparable:** negocio diferente sin conexión clara. 
Criterios de comparabilidad (0–3 por atributo, o no disponible): audiencia, job, geografía, modelo comercial, etapa/tamaño, canal de adquisición, complejidad de compra. *No sumar a ciegas; indicar desajustes.* Priorizar revisión representativa y no solo marcas populares.

## 3. Consultas de investigación: generar y diversificar
- Problema/JTBD: `"cómo [tarea] [segmento] [país]"`, `"[industria] [problema] solución"`.
- Competidores: `"[servicio] [localidad] alternativas"`, `[servicio] [idioma] plataformas`, `[plataforma] vs [plataforma]`.
- Características: `[competidor] pricing`, `[competidor] registro [rol]`, `[competidor] buscar profesionales`, `[competidor] reseñas`, `[competidor] documentación api`.
- Contradicciones: reseñas documentadas, páginas de soporte, reseñas de producto, términos, *release notes*, testimonios de usuarios reales; comprobar fecha, patrocinio y sesgo.
- Regulación/estándares pertinentes: buscar documentación primaria según país y vertical, no inventar compliance.
- Innovación: patentes, lanzamiento por fecha, productos en otras regiones, mercados adyacentes, soluciones offline. Una cobertura de búsqueda limitada NO prueba originalidad global.

## 4. Jerarquía de fuentes y evidencia
- Evidencia primaria interna: analítica autorizada, base CRM, tickets, logs, entrevista verificada, evaluación con usuarios; explicar tamaño de muestra y sesgos.
- Evidencia pública primaria: sitio oficial rival, documentación API, pricing público, help center, filings, términos. Puede verificar promesas o funcionalidades visibles, NO productividad/conversión interna.
- Evidencia secundaria confiable: estudios independientes, investigaciones académicas, comparativas identificando metodología.
- Testimonios/reseñas: señales cualitativas, no muestra estadísticamente representativa salvo diseño explícito.
- Hipótesis modelo: grado D; desconocido U. Registrar desactualización y cambios.

## 5. Ledger de evidencia (mínimo por claim)
`claim_id`, `texto`, `sujeto`, `categoria`, `tipo` (observación / entrevista / inferencia / estimación), `source_id`, `url`, `fecha_acceso`, `fecha_publicacion`, `metodo` (navegador, HTML, documento, API etc.), `estado` (`confirmado`, `inferido`, `desconocido`, `contradicho`), `limites`, `nivel_A_B_C_D_U`, `evidencia_contraria`, `accion_validacion`.
- Fuentes **fechadas** y URLs con intención de reproducibilidad, no enlaces inventados.
- Una captura o descripción visual no permite afirmar uso real, métricas o funnel completo. Restricción de login ≠ ausencia de característica.
- Dos fuentes que se copian entre sí no constituyen corroboración independiente.

## 6. Matriz competitiva por tareas (no catálogo indiscriminado)
Columnas: rival, categoría, segmento/mercado, trabajos clave, propuesta de valor, CTA/intención, experiencia de búsqueda, confianza/prueba social, onboarding por rol, pricing público, integraciones visibles, modelo de adquisición observado, diferenciación verificable, fricciones observables, evidencia, huecos y comparabilidad. Priorizar 4–6 criterios relacionados con los jobs. Un `no observado` nunca se puntúa como `no existe`.

## 7. Evaluar innovación con precisión
- `paridad`: la alternativa es ampliamente ofrecida entre comparables verificados.
- `diferenciación`: cambio perceptible por segmento frente a comparables concretos; no equivale necesariamente a innovación técnica.
- `novedad local`: poca evidencia en mercado objetivo, pero puede existir en otros mercados.
- `innovación plausible`: nuevo mecanismo/propuesta/experiencia con evidencia todavía limitada; requiere validación.
- `novedad no demostrada`: búsqueda insuficiente; **no** afirmar «primera plataforma» o «nadie lo hace».
Registra tiempo de consulta, profundidad, restricciones y alcance geográfico.

## 8. Stop conditions
Detener cuando comparables representan segmentos y sustitutos pertinentes y hallazgos se estabilizan; continuar si hay contradicción que cambia decisión, riesgo legal/integración o evidencia crítica faltante. Reportar `cobertura`, `búsquedas_no_resueltas`, `limitaciones` y `siguientes_validaciones`. Investigar no significa navegar sin límite.

## 9. Entregables 
1. Resumen ejecutivo de mercado; 2. lista de comparables con exclusiones; 3. matriz por jobs; 4. 5–10 patrones verificables y contraejemplos; 5. mapa de funcionalidades/experiencias; 6. oportunidades y defensibilidad; 7. juicio restringido de originalidad; 8. evidencia y huecos; 9. preguntas para usuarios; 10. puente a Gap Analysis (sin construir aún la solución).

## 10. Reglas de investigación segura
Respetar términos, robots, autenticación y propiedad intelectual; no explotar vulnerabilidades, comprar datos personales, crear cuentas falsas para burlar restricciones o publicar datos internos del cliente. Privacidad y origen de datos quedan trazados.
