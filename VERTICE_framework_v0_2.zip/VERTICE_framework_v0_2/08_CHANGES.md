# Cambios de v0.1 → v0.2

## Conservado
- Nombre conceptual VÉRTICE y siete dimensiones.
- Enfoque adaptativo (no ROI universal), EBM CV/UV/T2M/A2I, BRM.
- Evidencia A/B/C/D/U, BAU, score heurístico separado de confianza, costos internos separados de valor cliente.
- Aprobación humana y arquitectura de plataforma independiente del LLM.

## Ampliado
- 14 fases P00–P13 frente a 9 fases F0–F8 previas: **P01 auditoría humana; P02 auditoría IA ciega; P03 conciliación; P04 Deep Research autónomo; P05 ICP/JTBD y journeys; P06 capa específica de experiencia digital/tecnología/conversión**.
- P04 incluye búsquedas, criterios de selección, tareas competitivas, juicio restringido de innovación, fuentes fechadas y auditoría de referencias.
- Se separa la promesa de marketing de la experiencia y activación reales (`channel–message–landing–CTA–activation`).
- Se añaden prompts granulares portables, decisión por gate, JSON v0.2, archivos de plantilla y calculadora verificable.
- Los documentos incorporan defensa contra alucinaciones, restricciones de navegación y obligación de declarar modo de observación.

## Migración de fases
| v0.1 | v0.2 |
|---|---|
| F0 Intake | P00 |
| F1 Inteligencia externa | P04, precedido de P01–P03 |
| F2 Diagnóstico interno | P01–P03, P05 y P06 |
| F3 Gaps | P07 |
| F4 Qualification | P08 |
| F5 Alternatives/Business case | P09–P10 |
| F6 Comercial | P11 |
| F7 Propuesta | P12 |
| F8 Realización | P13 |

## Cambios futuros sugeridos
- Calibración cuantitativa con casos reales antes de usar scores para comparar cartera.
- Añadir herramientas que realicen testing de journeys, rendimiento real, SEO y analítica solo con permisos y evidencia.
- Pantalla de contradicciones humano vs modelo y laboratorio de sensibilidad.
- Conservar historia de pronósticos, esfuerzos, márgenes y beneficios medidos por arquetipo, con protección de datos.
