# VÉRTICE v0.2 — Sistema operativo de investigación, diagnóstico, valor y cotización
**Estado:** especificación ejecutable por prompts + contratos de datos + utilidades deterministas; NO es aún una plataforma web.  
**Fecha:** 2026-11-04. **Autoría conceptual:** framework propuesto para consultoría tecnológica, no una norma certificada.

## Qué cambia respecto de v0.1
- El **orden real** inicia con *revisión humana independiente*, *auditoría independiente de IA* y *conciliación argumentada*.
- **Market/Competitive Intelligence incluye un prompt especializado de Deep Research**, fuentes fechadas, búsqueda de directos, indirectos, sustitutos, referencias aspiracionales y evaluación de innovación.
- Se agregan explícitamente: *investigación ICP/JTBD*, *arquitectura de información y journeys*, *diagnóstico de conversión por segmento y canal*, *auditoría técnica*, *teoría de cambio*, *alternativas vs BAU*, *gates*, *seguimiento*.
- Cada paso tiene `input`, `prompt`, `output`, `gate` y `retrabajo`; se puede ejecutar un módulo sin empezar desde cero.
- Finanzas adaptativas según el arquetipo; **precio interno separado del beneficio del cliente**.
- Contrato JSON v0.2 y ejemplo, motor de cálculos deterministas, verificador básico y pruebas.

## Inicio rápido (sin programar)
1. Reúne URL, brief, objetivos y notas de tu **inspección humana** en `plantillas/01_FICHA_CLIENTE.md` y `plantillas/02_AUDITORIA_HUMANA.md`.
2. Da al agente `02_PROMPT_ORQUESTADOR.md` y `01_WORKFLOW_COMPLETO.md`. Puedes utilizar módulos por separado desde `prompts/`.
3. **No le muestres tus conclusiones al modelo en P02**: ejecuta su auditoría ciega por separado; recién en P03 compara las evaluaciones.
4. Ejecuta **P04 en modo investigación profunda con navegación**; pide URLs y citas por afirmación. Si el agente no tiene navegación o navegador, devolverá un PLAN, no hallazgos supuestamente observados.
5. Continúa P05–P12 y pasa cada *gate*; si falta evidencia, ofrece un diagnóstico/piloto en lugar de poner números imaginarios.
6. Revisa y firma alcance, costos, precio y propuesta antes de enviarla al cliente.

## Árbol de documentos
- `01_WORKFLOW_COMPLETO.md`: 14 fases y mapa de decisiones; quién hace qué, entregables y criterios de avance.
- `02_PROMPT_ORQUESTADOR.md`: agente coordinador portable, sin sintaxis dependiente de proveedor.
- `03_MODELOS_Y_FORMULAS.md`: modelo de valor, diagnóstico, puntuación y cotización por tipo de negocio.
- `04_PROTOCOLO_INVESTIGACION.md`: métodos de búsqueda, fuentes, citación, comparación y auditoría de evidencias.
- `05_ARQUITECTURA.md`: diseño del futuro producto/agentes/almacenamiento y aprendizaje iterativo.
- `06_CASO_GUIADO.md`: caso sintético de plataforma de profesionales (nunca confundir con investigación real).
- `07_REFERENCIAS.md`: fuentes oficiales y nota de uso.
- `prompts/P00` a `P13`: instrucciones especializadas para copiar y ejecutar una etapa.
- `plantillas/`: fichas, auditorías, matriz competitiva, mapa de oportunidades y cotizador.
- `schemas/case_v0_2.schema.json`: esquema interoperable.
- `ejemplos/case_sintetico.json`: caso de prueba sin empresas reales.
- `herramientas/vertice_calc.py`: funciones deterministas (score, VAN, payback, pricing).
- `herramientas/validate_case.py`: validación local con jsonschema opcional.
- `herramientas/test_calculadora.py`: pruebas unitarias.

## Modo de uso recomendado
- **LITE (preventa):** P00, P01, P02, P03, P04 compacto, P07, P09, P11, P12. Informe exploratorio, no ROI concluyente.
- **STANDARD:** P00–P12, 3–7 comparables razonables, ICP/journeys y modelo de valor por arquetipo.
- **DEEP / ENTERPRISE:** todos los módulos, investigación profunda, entrevistas, datos analíticos, due diligence técnica, 3 escenarios, sensibilidad, trazabilidad completa, riesgos y aprobación.
- Los módulos no tienen que ejecutarse 14 veces si no aportan valor: *profundidad proporcional al riesgo/costo/irreversibilidad*.

## Reglas de integridad
- `no_observado` ≠ `no_existe`; una función oculta, de app, login o integración privada puede existir sin ser visible.
- No afirmar que una web está fallando sin pruebas: separar revisión experta, pruebas con usuarios y analítica.
- Competidor ≠ benchmark aplicable; feature ≠ beneficio, tráfico ≠ negocio, ahorro horario ≠ ahorro de caja.
- Ausencia de datos `null`, no cero. Evidencia A/B/C/D/U, fuentes fechadas, replicabilidad y límites.
- La IA redacta y propone hipótesis; los cálculos se verifican con código; el humano aprueba decisiones financieras y comerciales.
- No recolectar datos personales, saltar accesos ni usar scraping contrario a permisos/términos.

## Ejecutar verificaciones
```bash
python herramientas/test_calculadora.py
python herramientas/validate_case.py ejemplos/case_sintetico.json schemas/case_v0_2.schema.json
```
