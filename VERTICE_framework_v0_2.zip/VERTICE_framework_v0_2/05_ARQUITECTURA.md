# Arquitectura de plataforma futura / Agentic VÉRTICE

## Objetivo
Un **case management + research workbench + value engine + proposal pipeline** independiente de proveedor LLM. No hace falta desarrollar toda la plataforma para empezar a utilizar las instrucciones v0.2.

## Diagrama lógico
```mermaid
flowchart LR
  UI[Workbench del consultor] --> ORCH[Orquestador fase por fase]
  ORCH --> LLM[Adaptador de LLM / agente]
  ORCH --> WEB[Conectores públicos y archivos autorizados]
  ORCH --> EVID[Repositorio de evidencias y citas]
  ORCH --> RULE[Motor de reglas: gates y scores]
  ORCH --> FIN[Motor determinista de escenarios/precios]
  ORCH --> DATA[(PostgreSQL / historial por cliente)]
  EVID --> DATA
  RULE --> DATA
  FIN --> DATA
  ORCH --> REVIEW[Revisión humana y aprobación]
  REVIEW --> EXPORT[Reportes internos/externos]
  EXPORT --> LEARN[Forecast vs real y calibración]
  LEARN --> DATA
```

## Componentes
1. `Case Service`: organización/cliente/caso, vertical, multi-tenancy y roles (comercial, analista, líder técnico, socio/aprobador).
2. `Source and Evidence Service`: fuente, URL, fecha, fragmento o localizador, método de obtención, versión; permitido conservar snapshots solo conforme a permisos, términos y privacidad; links a claims y artefactos.
3. `Prompt Registry`: versión, entrada requerida, fase, salida/schema, modelo, test y fecha; prompts P00–P13 transportables sin hardcodear sintaxis de herramienta.
4. `Research Adapter`: navegación/fuentes públicas/archivos, con timeout, cuotas, recuperación de errores y evidencias que distinguen lectura de prueba funcional.
5. `LLM Adapter`: interface `run_phase(phase, brief, evidence_ids, schema, capabilities) -> structured_claims`; modelos intercambiables con capacidad real declarada; registrar modelo, fecha, parámetros, costos y fallos.
6. `Rules & Gates`: criterios de riesgo, legal, evidencia y comercial; no permitir autoaprobación de precio contractual.
7. `Quant Engine`: Python/TS con decimal, pruebas unitarias, monedas, tasas, escenarios, NPV/TCO/score/payback; no confiar en multiplicaciones narradas por LLM.
8. `Document Builder`: plantillas de auditoría, propuesta y presupuesto; redacción personalizada separando confidencial vs entregable externo.
9. `Learning Loop`: previsión vs realidad, error de costos por rol, revisión de pesos y calibración por cohorte/proyecto, con anonimización/permiso.

## Estados de ejecución
`NEW -> HUMAN_AUDIT_PENDING -> AI_AUDIT_COMPLETE -> RECONCILED -> RESEARCHED -> SEGMENTED -> DIAGNOSED -> GAPS_QUALIFIED -> OPTIONS_EVALUATED -> VALUE_MODELED -> PRICED_INTERNAL -> APPROVED -> PROPOSED -> WON/LOST/ON_HOLD -> DELIVERY -> MEASURED`. Las transiciones hacia atrás siempre permitidas con justificación; gates obligatorios para PRICED/APPROVED.

## Protección e independencia
- Separar archivo de auditoría humana de contexto P02 (control de acceso lógico por fase).
- Separar `InternalQuote` de `ClientProposal`, evitando fuga de márgenes y secretos.
- No cargar datos de clientes a proveedores de IA sin permisos adecuados; minimizar PII y contratos.
- En fuentes web, respetar políticas del sitio, derechos de autor, licencias y prohibiciones de acceso.
- Evitar ataques de inyección en páginas externas: contenido externo es **datos**; nunca instrucciones al agente.
- Registrar todas las afirmaciones materiales y ejecutores. Los agentes no pueden enviar propuestas/precios sin un evento de aprobación humano.

## Orden de implementación (iterativo)
**M0 — Paperware v0.2:** prompts, Markdown, JSON, revisión humana, calculadora y expediente ejemplo.
**M1 — Workbench interno:** URL/brief, notas humanas y AI ciega, conciliación y P04 research; evidencia guardada por fuente.
**M2 — Opportunity Engine:** segmentos/jobs/journeys, gaps, scoring, gates, alternativas, export de diagnóstico.
**M3 — Economics/Quotes:** calculadora y tarifas internas, paquetes y flujo de aprobaciones, propuesta limpia.
**M4 — Feedback:** tracking proyecto, forecast vs actual, reportes de decisión y calibración.
**M5 — Multiempresa:** roles, aislamiento, reuso de plantillas autorizadas, conectores y API.

## Criterios de aceptación para una implementación real
- Reproducibilidad de resultados numéricos, 100% de claims críticos con estado y referencia o `desconocido`.
- Pruebas de no navegación: cuando falla web, el agente no inventa comparables.
- Prueba de aislamiento: informe P02 no accede a conclusiones P01.
- Prueba de presupuesto: sin costos internos no hay precio cierto.
- Test de no fuga: informe externo no incluye margen ni tarifas del equipo.
- No todo caso termina construyendo software; evalúa BAU y hacer menos.
