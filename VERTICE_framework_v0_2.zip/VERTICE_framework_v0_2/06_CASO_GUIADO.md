# Caso guiado — Plataforma hipotética que conecta usuarios con profesionales
**Propósito:** demostrar los handoffs y cómo cambia la recomendación según evidencia. **NO es un análisis efectuado sobre una plataforma real.** Las personas, métricas y necesidades son hipótesis ilustrativas. No hay rivales verificados ni números inventados.

## P00 — Encargo
Petición literal: «Quiero una web moderna donde se registren profesionales y clientes puedan encontrarlos». Necesidad posible: clientes tienen dificultad para descubrir, comparar y contactar perfiles confiables; profesionales necesitan obtener oportunidades relevantes. Resultado deseado: reducir tiempo para conectar oferta y demanda y aumentar solicitudes cualificadas.

Dos actores: `SEG-DEMAND` (quien contrata) y `SEG-SUPPLY` (quien ofrece servicio). Un tercer actor podría ser administración/soporte. En empresa que contrata profesionales, comprador y usuario no siempre coinciden. Hipótesis separadas por lado.

## P01 — Inspección humana (NO ejecutada)
El consultor inspeccionaría: `buscar por especialidad`, `filtrar ubicación`, `ver experiencia/precios`, `entender confiabilidad`, `solicitar contacto`, `registrarse como profesional`, `editar perfil`. Documentaría ruta real, resultados y problemas con pruebas; en este caso **pendientes**.

## P02 — IA ciega (NO ejecutada)
Un agente con navegador recibiría URL y tareas neutrales, pero no las conclusiones P01. Generaría otra auditoría basada en rutas reproducibles. Si no hay navegador, produce solo checklist y deja `NOT_OBSERVED`.

## P03 — Conciliación
Supongamos que humano dice «el registro exige demasiados pasos» y agente dice «el registro es breve». No promediar opiniones. Hipótesis explicativas: uno usó registro para cliente y otro para profesional; probar ambos roles y documentar URLs/etapas. Si no se puede probar, discrepancia abierta. Este ejemplo no afirma que haya ocurrido.

## P04 — Deep Research del mercado
Buscar plataformas que resuelvan mismo JTBD, directorios locales, agencias de intermediación, comunidades/redes y servicios manuales de referencia. Matriz por tareas equivalentes, no «tiene chat/no tiene chat». Se requiere web para identificar comparables reales, por lo que aquí **no se nombran**.

**Ejemplo de pregunta de investigación**: ¿qué atributos de un perfil ayudan realmente a confiar en un profesional y cuáles se muestran públicamente en alternativas relevantes? Comparar público e intención local antes de importar patrones de otro país.

## P05 — Dos journeys con rutas distintas
`SEG-DEMAND`: descubre servicio → formula necesidad → encuentra candidatos → evalúa confianza → solicita contacto → recibe respuesta → contrata → evalúa.
`SEG-SUPPLY`: descubre plataforma → comprende beneficio → se registra → verifica identidad/credenciales si corresponde → publica perfil → responde lead → realiza servicio → repite.

La web puede fallar en captar oferta y funcionar bien para demanda, o viceversa. Cada lado necesita KPIs propios, diseño, copy y CTA; más visitas a un lado no producen necesariamente mejor matching.

## P06/P07 — Diagnóstico y gap
Posible `GAP-1`: categorías no reflejan cómo busca el usuario (hipótesis). Causa candidata: taxonomía diseñada desde backend, no desde lenguaje de clientes. Intervención alternativa A: reorganizar información; B: filtros más relevantes; C: buscador semántico (muy posterior). KPI: tiempo y éxito de tarea `hallar profesional adecuado`, medidos con usuarios.

Posible `GAP-2`: profesionales abandonan el registro (hipótesis). Intervención más barata: simplificar textos/campos, sin construir nueva plataforma. KPI: finalización por etapa y tiempo de alta.

## P08 — Gates
Si no hay pruebas de problema, hacer test de tareas y medición de embudo. No priorizar solo por gusto del diseñador. Si hay datos de abandono y problemas de disponibilidad, priorizar exploración de calidad de matches antes de nueva infraestructura.

## P09 — Alternativas
- `BAU`: seguir plataforma y medir, con costo y riesgo actual (pendiente).
- `DO_MINIMUM`: revisar copy, navegación, taxonomía y formularios.
- `CONFIGURE/BUY`: integrar directorio/CRM/buscador existente si cubre roles.
- `MVP`: construir onboarding y filtro de alta prioridad con tracking.
- `CUSTOM`: plataforma bilateral, validación, mensajería, integraciones, pagos, moderación, escalamiento. Solo si demuestra ventaja.

## P10 — Modelo específico marketplace
No aplicar «tráfico adicional × precio» como si fuera solo un brochure. Núcleo de valor: **liquidez**, contactos relevantes, calidad de match y tiempo a respuesta. Variables a obtener: `usuarios que buscan`, `profesionales disponibles por especialidad/zona`, `tasa de solicitudes cualificadas`, `respuesta`, `contratación`, `take rate` si hay comisión, contribución neta por transacción, tasa de repetición.

`Contribución incremental = (transacciones realizadas_con - transacciones_BAU) × margen de contribución por transacción`, con ajuste por costos variables no incluidos y sin inventar tasas. Una mejora de búsqueda que eleva leads pero sobrecarga a profesionales puede disminuir el outcome de calidad; medir ambos lados.

## P11/P12 — Costeo y propuesta
Presupuestar un diagnóstico de UX/mercado primero si el problema no fue confirmado; luego quick wins y MVP con entregables. Una cotización completa de marketplace sin verificar dependencia del lado oferta/demanda es demasiado riesgosa. La propuesta al cliente muestra resultados y compromisos medibles, sin incluir salarios ni márgenes internos de tu equipo.

## P13 — Retroalimentación
Instrumentar eventos por segmento y un KPI conjunto de `solicitudes atendidas que terminan en resultado`, no únicamente visitas, likes o registros. Comparar resultados frente a BAU razonable, con estacionalidad y fuentes de adquisición.

## Demostración del salto de razonamiento
**Mal razonamiento:** «Rival X tiene geolocalización, por lo tanto debemos hacer geolocalización y cobrar S/ Y».
**Buen razonamiento:** «Los usuarios que buscan un servicio local deben confirmar disponibilidad por zona; si la localización causa abandono (pendiente de probar), podemos empezar mostrando barrios atendidos y medir finalización de solicitudes; solo construir mapa/geolocalización si la prueba confirma ventaja clara frente a alternativas más baratas».
