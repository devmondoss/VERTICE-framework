# Referencias técnicas / bibliografía de referencia

Fuentes públicas primarias consultadas para diseñar VÉRTICE v0.2 (consulta: 2026-11-04). Son inspiración / referencia técnica; **VÉRTICE es una integración propuesta, no certificada por estas organizaciones**.

1. Scrum.org, *Evidence-Based Management Guide* (2024). https://www.scrum.org/resources/online-evidence-based-management-guide — CV, UV, T2M, A2I y ciclos de experimentación.
2. HM Treasury, *The Green Book (2026)*, actualización oficial 28 octubre 2026. https://www.gov.uk/government/publications/the-green-book--2/the-green-book-2026 — BAU, opciones, objetivos, incertidumbre y Five Case Model. La metodología fue creada para evaluación pública y se adapta, no se copia normativamente, a cotizaciones comerciales.
3. Nielsen Norman Group, *Competitive Usability Evaluations: Definition* (2024). https://www.nngroup.com/articles/competitive-usability-evaluations/ — evaluación competitiva.
4. Nielsen Norman Group, *Parallel & Iterative Design + Competitive Testing* (2024). https://www.nngroup.com/articles/parallel-and-iterative-design/ — diferencia entre revisión competitiva y pruebas con personas.
5. Nielsen Norman Group, *UX Benchmarks*. https://www.nngroup.com/articles/product-ux-benchmarks/ — éxito/tareas y comparaciones UX.
6. Nielsen Norman Group, *Journey Mapping 101*. https://www.nngroup.com/articles/journey-mapping-101/ — mapa de recorridos.
7. Nielsen Norman Group, *Research for Journey Mapping*. https://www.nngroup.com/articles/research-journey-mapping/ — investigación primaria.
8. Strategyzer, *The Value Proposition Canvas*. https://www.strategyzer.com/library/the-value-proposition-canvas — trabajos, pains y gains.
9. Google Search Central, *SEO Starter Guide*. https://developers.google.com/search/docs/fundamentals/seo-starter-guide — contenidos útiles, navegación e intención.
10. Google Search Central, *Core Web Vitals*. https://developers.google.com/search/docs/appearance/core-web-vitals — LCP, INP y CLS.
11. W3C, *Web Content Accessibility Guidelines 2.2*. https://www.w3.org/TR/WCAG22/ — accesibilidad web.
12. NIST, *Generative AI Profile* (2024). https://www.nist.gov/publications/artificial-intelligence-risk-management-framework-generative-artificial-intelligence — gestión de riesgos y verificación de sistemas IA.
13. PMI, *Benefits Realization Management: A Practice Guide*. https://www.pmi.org/standards/benefits-realization — vincular proyectos con beneficios sostenibles.
14. ISO/IEC 25010:2023, https://www.iso.org/standard/78176.html — marco de calidad de producto software; no afirmar certificación por mera inspección.
15. Forrester, *Total Economic Impact*. https://www.forrester.com/policies/tei/ — beneficios/costos/flexibilidad/riesgos; las marcas y métodos son de sus titulares.

**Nota**: las rúbricas de score, pesos, fases y gates exactos de VÉRTICE no proceden textualmente de ninguna referencia; son hipótesis de proceso que deben calibrarse con proyectos reales.
