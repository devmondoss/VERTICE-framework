# VÉRTICE · Ficha del caso (`CASE-ID`)
**Fecha:** [ ]  **Analista:** [ ] **Modo:** LITE / STANDARD / DEEP

| Campo | Dato confirmado | Fuente / fecha | Desconocido / permiso pendiente |
|---|---|---|---|
| Empresa / URL | | | |
| Industria / región | | | |
| Qué pide literalmente | | | |
| Qué problema espera resolver | | | |
| Objetivo/outcome | | | |
| Cliente pagador / usuario / decisor | | | |
| Modelo comercial | | | |
| Restricciones y plazos | | | |
| Sistemas e integraciones | | | |
| Datos internos disponibles | | | |
| Canales actuales | | | |
| Expectativa presupuestaria comunicada | | | |

**Tareas neutrales para auditar**
1. [ ] Encontrar información de [servicio] desde la página de inicio.
2. [ ] Comparar alternativas para [segmento].
3. [ ] Completar/intentar ruta de contacto o registro, sin efectuar transacción real.
4. [ ] Identificar señales de confianza, términos y siguiente paso.

**Cuestiones que cambian la decisión (máx. 7):** [ ]
**Permisos de investigación:** web pública [ ]; interna [ ]; analítica [ ]; código [ ].
