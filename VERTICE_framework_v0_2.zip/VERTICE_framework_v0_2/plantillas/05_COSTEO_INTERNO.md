# VÉRTICE · COSTEO CONFIDENCIAL — NO ENTREGAR A CLIENTE
**Caso:** [ ] **Opción:** [ ] **Moneda:** [ ] **Versión:** [ ] **Aprobador:** [ ]

| WBS | Rol | Horas mín/base/máx | Costo cargado por hora | Costos mínimos/base/máx | Dependencias / evidencia |
|---|---|---|---|---|---|
| Discovery | | | | | |
| UX/IA/contenidos | | | | | |
| Frontend | | | | | |
| Backend/integraciones | | | | | |
| QA/seguridad | | | | | |
| PM/DevOps/entrega | | | | | |

Costos terceros: [ ] · Overhead imputado: [ ] · Riesgo/reserva no duplicada: [ ] · Soporte contractual: [ ]

`Cost_allin`: [ ] · `Margin_target`: [ ] · `Precio floor = costo/(1-margen)`: [ ] · `WTP validada`: [ ] · `Referencia mercado`: [ ]

## Empaques / escenarios
| Paquete | Scope y criterios aceptación | Coste | Precio aprobado | Margen esperado | Hitos | Exclusiones |
|---|---|---|---|---|---|---|

**Gate humano:** pendiente / aprobado / rechazado. **Nunca exponer este archivo en propuesta externa.**
