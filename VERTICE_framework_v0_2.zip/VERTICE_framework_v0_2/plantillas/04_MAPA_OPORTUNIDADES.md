# VÉRTICE · Gap → Value → Experimento

| GAP-ID | SEG/JOB | Problema y evidencia | Causa hipotética | BAU / alternativa sin desarrollo | Cambio propuesto | Outcome/KPI | Impacto esperado (evidencia) | Experimento/falsador |
|---|---|---|---|---|---|---|---|---|

## Score de oportunidades (NO probabilidad)
| OPP-ID | P 20 | I 20 | S 15 | F 15 | A 15 | D 15 | Score parcial/completo | A/B coverage | Gate |
|---|---|---|---|---|---|---|---|---|---|

## Registro de decisiones
- Opciones: BAU / mínima / comprar-configurar / MVP / a medida.
- Riesgos no mitigados: [ ]
- Decisión y justificación: [ ]
- Evidencia necesaria para cambiarla: [ ]
