# VÉRTICE · Revisión humana ciega (`CASE-ID`)
**Evaluador:** [ ] **Fecha/hora:** [ ] **Dispositivo/viewport:** [ ] **Sesión/accesos:** [ ]

## Tareas
| Task-ID | Objetivo del usuario | Ruta exacta / URL | Resultado observado | Evidencia | No verificable |
|---|---|---|---|---|---|
| TASK-01 | | | | | |
| TASK-02 | | | | | |

## Observaciones
| OBS-H-ID | Observación factual | Interpretación separada | Categoría | Severidad 0–4 | Segmento/Task | Fuente/captura |
|---|---|---|---|---:|---|---|
| OBS-H-01 | | | | | | |

## Hipótesis a refutar y datos faltantes
- [ ]

**IMPORTANTE: congelar este informe antes de leer auditoría IA.**
