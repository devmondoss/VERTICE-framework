# VÉRTICE · Competitive Intelligence
**Mercado:** [ ] **Fecha consulta:** [ ] **Segmentos:** [ ] **Decisión:** [ ]

## Composición del universo
| CMP-ID | Referencia | Tipo (directo/indirecto/sustituto/aspiración) | Segmento/job/mercado | Comparabilidad + límite | SRC-ID |
|---|---|---|---|---|---|

## Matriz task-based
| CMP-ID | Job/tarea | Promesa al usuario | Entrada/CTA visible | Búsqueda/selección | Confianza | Registro/contacto | Estado observado/no observable | SRC-ID |
|---|---|---|---|---|---|---|---|---|

## Registro de evidencia
| SRC-ID | Claim específico | Fuente/URL | Fecha acceso | Método | Grado A/B/C/D/U | Límites y contradicciones |
|---|---|---|---|---|---|---|

## Originalidad
Paridad observable: [ ] · Diferenciación contextual: [ ] · Novedad local plausible: [ ] · Novedad no demostrada: [ ].

## Consultas sin resolver / experiments
- [ ]
