# VÉRTICE v0.2 — Workflow iterativo y estándar operacional

## Meta
Convertir un contacto comercial o idea de software en una **decisión defendible**: construir, comprar, optimizar, investigar, experimentar, postergar o no ofertar. La oferta se justifica mediante problemas, evidencia, usuarios, alternativas, valor contextual, costos internos y capacidad de ejecución. El flujo combina autonomía de IA con criterio humano, no desplaza las decisiones de ingeniería.

## Artefactos con IDs estables
- `CASE-...`: expediente. `SRC-...`: fuentes verificables. `OBS-H-...`: observación del analista humano. `OBS-AI-...`: observación del modelo.
- `DIS-...`: discrepancia. `CMP-...`: comparables. `SEG-...`: segmento. `JOB-...`: trabajo del usuario. `JRN-...`: recorrido.
- `GAP-...`: brecha; `OPP-...`: oportunidad; `HYP-...`: hipótesis causal; `OPT-...`: alternativa; `BEN-...`: beneficio; `KPI-...`: métrica; `RISK-...`: riesgo.
- Cada hallazgo contiene observación, interpretación, severidad cuando aplique, evidencia y `status` (`observado`, `inferido`, `supuesto`, `no_observado`, `desconocido`, `refutado`).
- Los documentos internos y externos son **vistas** del mismo expediente; la propuesta al cliente jamás expone los costos ni márgenes internos.

## Diagrama del funnel y bucles
```mermaid
flowchart TD
 A[00 Recepción y encuadre] --> B[01 Auditoría humana AS-IS]
 A --> C[02 Auditoría IA independiente]
 B --> D[03 Conciliación y discrepancias]
 C --> D
 D --> E[04 Deep Research mercado y competidores]
 E --> F[05 Segmentos JTBD y journeys]
 F --> G[06 Auditoría digital y tecnológica]
 G --> H[07 Brechas y teoría de cambio]
 H --> I{08 ¿Evidencia suficiente?}
 I -->|No| J[Experimento entrevistas o PoC]
 J --> E
 I -->|Sí| K[09 Alternativas BAU comprar configurar construir]
 K --> L[10 Modelo de valor y escenarios]
 L --> M[11 Costeo interno y pricing]
 M --> N{Gate comercial humano}
 N -->|Revisar| K
 N -->|Aprobar| O[12 Propuesta y negociación]
 O --> P[13 Implementar medir aprender]
 P --> H
```

## Tabla maestra de ejecución
| Fase | Responsable principal | Input clave | Salida de fase | Gate / rechazo | Prompt |
|---|---|---|---|---|---|
| P00 Encuadre | Comercial + agente | URL/brief/objetivos | `case_brief` y plan proporcional | ¿objeto, alcance y permisos entendidos? | `prompts/P00_BRIEF.md` |
| P01 Auditoría humana | Ingeniero | Web / producto / acceso autorizado | `human_audit` sin sesgo de IA | Evidencias y tareas observadas | `P01_AUDITORIA_HUMANA.md` |
| P02 Auditoría IA ciega | Agente + navegación si disponible | SOLO brief, URL; no conclusiones humanas | `ai_audit` y vacíos | Sin inventar navegación y datos | `P02_AUDITORIA_IA.md` |
| P03 Conciliación | Ingeniero + agente | P01 + P02 | `disagreement_register`, hipótesis | Resolver alta severidad o marcar pendiente | `P03_CONCILIACION.md` |
| P04 Market Intelligence | Agente investigación profunda | industria, segmentos, competencia preliminar | mapa competitividad y `evidence_ledger` | cobertura razonable, URL por afirmación, fecha | `P04_DEEP_RESEARCH_COMPETIDORES.md` |
| P05 Segmento/JTBD/journey | UX/negocio + agente | P03–P04, entrevistas o hipótesis | ICPs, jobs, journeys, canales y conversión | usuario real vs persona hipotética diferenciados | `P05_SEGMENTOS_JOURNEYS.md` |
| P06 Diagnóstico digital | Arquitecto + UX + agente | P01–P05, métricas/accesos autorizados | informe UX/IA/SEO/tech/data/seguridad | no confundir heurística con medición | `P06_AUDITORIA_DIGITAL.md` |
| P07 Gaps y oportunidades | Producto + agente | hallazgos rastreables | gap register y cadena causal | cada gap ligado a objetivo y usuario | `P07_GAPS_CAMBIO.md` |
| P08 Puntuación y validación | Producto + dirección | P07, evidencia y restricciones | scorecard + experimento mínimo | bloqueos de seguridad, legalidad o evidencia | `P08_SCORE_GATES.md` |
| P09 Alternativas y diseño | Arquitecto + producto | oportunidades priorizadas | BAU, quick-win, buy, build, phased MVP | comparar opciones bajo restricciones | `P09_ALTERNATIVAS.md` |
| P10 Impacto y finanzas cliente | Analista + agente + calculadora | KPIs, costos, demanda, escenarios | business case por arquetipo | bases y tasas defendibles o 'no estimable' | `P10_MODELOS_VALOR.md` |
| P11 Costeo y cotización interna | Líder técnico + socio | esfuerzo/roles/tarifas/capacidad | floor, precio, empaques, contingencia | aprobación humana y margen sostenible | `P11_COSTEO_PRECIO.md` |
| P12 Propuesta externa | Comercial + dirección | documento aprobado por gates | informe ejecutivo, cotización, roadmap | sin datos internos ni promesas infundadas | `P12_PROPUESTA.md` |
| P13 Entrega/medición | PO + cliente + equipo | contrato, baseline, KPIs | experimentos, valor realizado, calibración | revisiones programadas y responsables | `P13_MEDICION.md` |

## Orden de verdad: auditoría humana/IA
1. El ingeniero observa una tarea concreta, p. ej. `encontrar profesional -> comparar -> contactar`, y registra paso, URL/captura, dispositivo, restricciones y resultado.
2. El agente recibe **brief + URL + tareas**, pero **no** el juicio del ingeniero. Su modo de operación puede ser: `browser_observed`, `http_content_only` o `no_web`; el informe dice cuál fue.
3. P03 concilia: acuerdo comprobado, desacuerdo por interpretación, falta de observación o contradicción factual. No promediar notas como si fueran dos evaluadores independientes calibrados. Un mismo error de fuente puede contaminar ambos.
4. Para afirmaciones sobre facilidad, éxito de tareas o conversión, pedir datos y/o sesiones con usuarios; una evaluación experta es hipótesis de riesgo, no experimento.

## Mercado: investigación que conduce a decisión
La investigación se centra en **jobs y casos de uso**, no solo una lista de competidores. Delimitar región, segmentos y sustitutos. Hallar comparables: 2–4 directos, 1–2 indirectos/sustitutos y 1–2 referentes adyacentes cuando existan. Número flexible (no inventar rivales para completar cuotas).

Preguntas obligatorias: (a) ¿qué intentan resolver los usuarios? (b) ¿a quién atienden los rivales? (c) ¿qué acciones permiten realmente sus interfaces observables? (d) ¿cómo monetizan, si es público? (e) ¿qué barreras de adopción y confianza parecen relevantes? (f) ¿qué oportunidades no están satisfaciendo? (g) ¿qué soluciones pueden ser sustitutos no tecnológicos? (h) ¿qué información falta para hablar de innovación?

Innovación no equivale a `feature ausente de 5 webs`. Clasificar novedad del **mercado investigado**, modelo de negocio, proceso, canal, experiencia y tecnología; emitir `novedad no demostrada` si la cobertura o el historial son insuficientes.

## Segmentación y estrategia de adquisición
Para cada `SEG`: perfil (empresa/consumidor/decisor/usuario/finanzas/regulador cuando aplique), `JOB`, dolor, objeción, criterios de elección, canal de llegada e intención probable. Traza: `canal/consulta -> mensaje/oferta -> landing/contexto -> prueba y confianza -> CTA pertinente -> formulario/registro -> activación -> resultado`. No optimizar solo clics; medir calidad y finalización del proceso. Las recomendaciones de visibilidad consideran contenido útil, SEO, búsqueda de marca, canales de referencia, accesibilidad y analítica consentida. Pagos por anuncios (pauta) son una opción de adquisición, no sustituto de relevancia del producto.

## Teoría de cambio por oportunidad
`SRC -> OBS -> USER/JOB -> fricción -> causa raíz hipotética -> intervención -> comportamiento habilitado -> outcome -> beneficio -> objetivo -> KPI -> fórmula / prueba -> owner`.
Contraejemplo: `Agregar chatbot porque el competidor tiene uno` es feature copying, no argumento. Mejor: `Usuarios no completan solicitudes por incertidumbre de disponibilidad (datos por validar); evaluar disponibilidad en ficha; medir proporción solicitud completada y tiempo de respuesta`.

## Gates transversales
- **G0 Problema**: si cliente solo pidió tecnología, no tratar su solución predilecta como necesidad demostrada.
- **G1 Investigación**: sin navegación, `deep research NOT DONE`; producir fuentes sugeridas y protocolo; no simular consulta.
- **G2 Evidencia**: gap crítico sin fuente verificable → `INVESTIGAR` o `PILOTO`.
- **G3 Factibilidad**: integraciones, seguridad, privacidad, cumplimiento, datos y capacidad de entrega validados; incertidumbre alta → discovery técnico pagado/PoC.
- **G4 Business case**: BAU incluido, evitar beneficios duplicados, escenario conservador/base/alto si hay inputs; monetización no forzosa.
- **G5 Comercial**: costos, margen, hitos, alcance, exclusiones, impuestos y responsabilidad humana revisados.
- **G6 Validación**: compromiso de medición y owner del beneficio, según proyecto; no prometer resultados fuera del control del proveedor.

## Profundidad proporcional y condición de parada
- **LITE**: oportunidad pequeña/bajo riesgo, inspección humana y IA + comparables mínimos, checklist UX/tech, riesgos y cotización basada en costos; sin pronóstico falso.
- **STANDARD**: proyecto multicomponente, jornadas por rol, entrevistas si puede, investigación y escenarios robustos.
- **DEEP**: integración crítica, regulado, irreversible, multiempresa o alta inversión; due diligence, evidencia primaria y análisis de sensibilidad/seguridad.
- **Stop** cuando: (1) criterios de éxito están definidos, (2) comparables suficientes para la decisión, (3) incertidumbres materiales registradas y mitigadas, (4) investigación adicional cuesta más que su valor probable. La IA debe decir por qué detuvo la búsqueda.

## Decisiones permitidas
`INVESTIGAR`, `EXPERIMENTAR`, `OPTIMIZAR_SIN_DESARROLLO`, `COMPRAR_CONFIGURAR`, `CONSTRUIR_MVP`, `CONSTRUIR_COMPLETO`, `POSPONER`, `NO_OFERTAR`.
La IA recomienda; el humano aprueba antes de contrato.

## Entregables por expediente
`00_brief.md`, `01_auditoria_humana.md`, `02_auditoria_ia.md`, `03_discrepancias.md`, `04_market_intelligence.md`, `04_fuentes.csv`, `05_segmentos_y_journeys.md`, `06_auditoria_digital.md`, `07_mapa_gaps.md`, `08_scorecard.md`, `09_alternativas.md`, `10_business_case.md`, `11_costeo_INTERNO.md`, `12_propuesta_CLIENTE.md`, `13_plan_medicion.md`, `case.json`.
No crear documentos vacíos ni duplicar investigación si una fase no aplica; documentar `NO_APLICA` y motivo.
