# VÉRTICE v0.2 — Motor de medición, valoración contextual y cotización

## 0. Las cuatro economías que no se deben confundir
1. **Valor económico/social creado** para stakeholders por una intervención, neto de impactos negativos y del escenario BAU.
2. **Valor capturado por el cliente** después de inversiones y costos de operar/adoptar la solución.
3. **Costo real de entrega para el proveedor** (ingeniería, terceros, riesgo, soporte comprometido, overhead).
4. **Precio y margen del proveedor** sujetos a oferta/demanda, negociación, presupuesto, riesgo y valor diferencial.
No existe una fórmula universal que convierta 1 en 4. El ROI del cliente nunca es el markup del proveedor.

## 1. Evidencia como infraestructura del modelo
- `A`: medición interna/experimento/registro verificable pertinente, con calidad y ámbito conocidos.
- `B`: dato documental del cliente o entrevista triangulada con contexto.
- `C`: fuente externa comparable pero con limitaciones de extrapolación.
- `D`: juicio experto/hipótesis, aún no validado.
- `U`: desconocido/contradicho.
Son categorías **internas de VÉRTICE** (no escala estándar ni garantía de predicción). Registrar siempre limitaciones y fecha. Recontar la cobertura A/B de claims CRÍTICOS, pero no convertir en confianza probabilística. Aun evidencia A sobre el estado actual no prueba el impacto futuro.

## 2. Score de oportunidad (heurístico)
| criterio | peso inicial | 0 | 3 | 5 |
|---|---:|---|---|---|
| Problema P | 20% | no comprobado/irrelevante | fricción importante acotada | frecuente/intenso y sustentado |
| Impacto I | 20% | beneficio ausente | outcome relevante plausible | impacto material sustentado |
| Estrategia S | 15% | contradice prioridades | alinea parcialmente | alinea objetivos críticos |
| Factibilidad F | 15% | inviable | viable con dependencias | viable demostrada |
| Adopción A | 15% | sin aceptación | adopción incierta moderada | adopción respaldada y cambio manejable |
| Diferenciación D | 15% | alternativa dominante mejor | mejora contextual | ventaja verificable importante |

`Score_full = 100 * Σ(w_i × s_i/5)`, con `Σw_i=1`, todos `s_i` numéricos 0..5. Si falta dato: `Score_partial = 100*Σ_known(w_i*s_i/5)/Σ_known(w_i)`, mostrar `coverage_weight=Σ_known(w_i)` y status **PROVISIONAL**; sin gate de aprobación por score. Congelar pesos por versión y antes de evaluar. No comparar scores de arquetipos diferentes salvo calibración explícita.

### Índices complementarios, no mezclados
- `evidence_coverage = claims_críticos_A_B / claims_críticos_total` si total>0; reportar A,B,C,D,U por separado.
- `severity` de fricción 0–4 documentada con tarea, frecuencia observada y fuente (no inferir incidencia sin analytics).
- `feasibility_gate`: aprobado/bloqueado/pendiente, razones.
- `commercial_fit`: margen, equipo, capacidad, pago, concentración, reputación; evaluación interna independiente.
- `impact_proof`: validado / hipótesis / sin forma de atribución; no asimilar a probabilidad.

## 3. Selección de modelos por arquetipo
| Contexto | Núcleo causal | Datos mínimos | KPI de decisión | Uso de ROI |
|---|---|---|---|---|
| Landing/corporativa | visitantes cualificados → contacto → venta | sesiones segmentadas, leads, tasa cierre, contribución | contribución incremental neta, CPA, conversión | si hay atribución/baseline |
| Ecommerce/checkout | intención → compra pagada válida | sesiones, CVR, ticket, contribución, devoluciones, fee | margen por sesión, aprobación pagos | frecuente si evidencia |
| Operaciones/automatización | tiempo/error/capacidad → costo evitado | frecuencia, minutos, salario cargado, tasa captura | costo por proceso, capacidad, errores | puede usarse VAN/TCO |
| SaaS B2B | adquisición → activación → expansión/retención | cohortes, MRR, margen, CAC, churn | payback CAC, NR/GR retention, contribución | prematuro antes datos |
| B2C digital | adquisición → retención → monetización | activación, DAU/MAU contextual, cohorte, ingreso/neto | retención, CLV fiable o proxies | depende de validación |
| Marketplace | densidad → matching → transacciones | supply activa, demanda, fill rate, take rate, margen | matching, liquidez, tiempo al match | solo luego de pilotos |
| Infraestructura | confiabilidad/capacidad → costo/riesgo | incidentes, downtime, costos cloud, SLO | TCO, SLO, incidentes, MTTR | si riesgo/cuanti defendible |
| Seguridad/privacidad | reducir exposición y cumplir deberes | amenazas, controles, obligaciones, incidentes | riesgo residual, cumplimiento, costo-efectividad | opcional, a menudo inapropiado |
| IA/analítica | mejor decisión → costo errores/tiempo | dataset, validación, prevalencia, FPR/FNR, humano | utilidad neta de decisión, drift, tasa intervención | solo con piloto |
| Público/ONG | prestaciones → outcomes sociales | cobertura, equidad, calidad, costo, accesibilidad | costo por outcome, impacto social | VAN social si procede |

## 4. Fórmulas y convenciones (evitar contradicciones)
Definir unidades, horizonte H, moneda, escenario base comparador, tasas e impuestos.

### 4.1 Margen incremental por embudo
`Leads_qual_t = Visits_t × rate_visit_to_lead_t × rate_qualified_t`
`Sales_t = Leads_qual_t × rate_close_t`
`Incremental_Contribution_t = (Sales_solution_t - Sales_BAU_t) × contribution_per_sale_t`
Si contribución/unidad ya excluye costo variable de adquisición o comisiones, no restar nuevamente. Considerar diferencias en tráfico, canales y capacidad de ventas.

### 4.2 Captura económica del tiempo
`Hours_freed_t = volume_t × Δminutes_per_task / 60`
`Cash_economic_benefit_t = Hours_freed_t × capture_rate_t × justified_cash_or_opportunity_value_per_hour`
Si `capture_rate` desconocida, no convertir a ahorro de caja. Si las personas mantienen el salario y no hay alternativa de producción/reasignación, el resultado es **capacidad liberada, no ahorro de caja automático**.

### 4.3 Pérdidas evitadas
`Expected_avoided_loss_t = (p_baseline - p_solution) × loss_given_event × exposure_t` usando probabilidades evidenciadas, horizonte consistente y sin asumir independencia de eventos si no corresponde. Si no se estiman probabilidad/impacto, describir riesgos cualitativamente.

### 4.4 Costos totales y flujo incremental
`TCO_H = I0 + Σ_t(licencias + mantenimiento + hosting + soporte + formación + integración + renovaciones + migración + retiro)` para horizonte H, sin duplicados.
`NetCF_t = Benefit_monetized_incremental_t - Incremental_operating_cost_t - Incremental_capex_t`; inversión inicial `I0` separado.
`NPV = -I0 + Σ_{t=1}^{H} NetCF_t/(1+r)^t`. Tasa r por periodo consistente (mensual si t meses). Riesgo explícito y escenarios: no «inflar» tasa arbitrariamente si ya ajustaste flujos por riesgo.
`ROI_simple_H = (Σ_t Benefit_net_operating_t - All_investment_H) / All_investment_H ×100%` define `Benefit_net_operating_t` y `All_investment_H` exactamente y evita contar inversión dos veces. Para flujos complejos, priorizar VAN y payback acumulado.
`Payback`: primera fecha t en que `-I0 + Σ_{k<=t} NetCF_k >= 0`; si no cruza, `null`. Aproximación `I0 / monthly_net_cf` solo con flujo mensual uniforme positivo.
`Incremental_Cost_Effectiveness = ΔCost / ΔOutcome` para efectos no monetizados; ΔOutcome debe ser de la misma naturaleza/escala.

### 4.5 Evidencia de efecto y sensibilidad
- `Δ` es **contra BAU**, no comparado ciegamente contra el estado actual.
- Tres escenarios (conservador/base/alto) mediante inputs documentados: adopción, costos, tiempo, conversión, permanencia.
- `Switching value`: input mínimo que vuelve preferible una alternativa, p. ej. conversión adicional necesaria para `NPV >= 0`.
- No construir Monte Carlo a partir de distribuciones inventadas. Mostrar sensitividad sobre 1–3 variables justificadas antes.
- Definir supuestos de atribución/causalidad: prueba A/B, cohortes, periodos comparables o advertir sesgos.

## 5. EBM: cuatro lentes, no un indicador compuesto
- **Current Value**: valor que perciben clientes hoy, calidad, satisfacción y uso.
- **Unrealized Value**: oportunidades insatisfechas justificadas, no potencial económico ficticio.
- **Time to Market**: capacidad para lanzar y aprender, lead/cycle time medidos.
- **Ability to Innovate**: capacidad organizacional para crear valor, deuda, defectos, tiempos de mantenimiento, flujos y bloqueos.
Se aplican en P05–P13 según contexto. No sumarlos como si fueran euros/soles ni usar un único porcentaje de valor EBM.

## 6. Ingeniería de precios — VÉRTICE interno
`Direct_EngCost = Σ_role(hours_role × loaded_hourly_cost_role)`.
`Cost_allin = Direct_EngCost + Third_party + Overhead_allocated + Delivery_costs + Support_committed + Risk_reserve` (comprobar que no hay dobles conteos).
`Suggested_price_floor = Cost_allin / (1 - target_gross_margin)` para `0 <= margin < 1`; esta fórmula supone margen sobre **precio**, no markup. Un margen del 30% no equivale a añadir 30% al costo.
`Realized_margin = (Net_sales - Real_cost)/Net_sales` bajo convención documentada; para manejo tributario usar net sales sin impuestos repercutidos si aplica.
**El precio recomendado no está dado por fórmula**: se valida con piso, competencia, margen, WTP sustentada, presupuesto, alternativa del cliente, riesgo, posicionamiento, condiciones de pago y valor diferencial.

### 6.1 Estructuras de contratación
- Diagnóstico pagado/Discovery: incertidumbre alta, cliente compra evidencia y alcance.
- Precio fijo por alcance: requisitos estables, riesgos acotados y proceso de cambios claro.
- T&M: alcance evolutivo, presupuesto y cadencia controlados.
- Retainer: mantenimiento, optimización y evolución continuada.
- Fase/piloto con opción de ampliación: innovación incierta, éxito por KPI.
- Variable por resultados: solo si el resultado es atribuible, auditable y pactado con límites.

## 7. Priorización adaptativa
Usar `RICE=(Reach × Impact × Confidence)/Effort` para backlog de un producto cuando haya unidades comparables; No aplicarlo entre proyectos de distinta industria sin normalización. Alternativa WSJF/costo de retraso cuando la información permite estimación; para riesgos obligatorios, gates y compliance priman sobre el puntaje.

## 8. Del research a una cotización defendible
El valor económico del proyecto surge de `problema × población afectada × magnitud × tasa de adopción × duración del beneficio` bajo causalidad y supuestos pertinentes. **No es una fórmula única**, es una estructura de pensamiento que se implementa de manera diferente según arquetipo. Después se calcula `TCO`, se comparan opciones y finalmente se deriva el precio con otro expediente financiero.
