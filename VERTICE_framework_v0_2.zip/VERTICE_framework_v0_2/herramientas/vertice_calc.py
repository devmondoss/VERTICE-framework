"""VÉRTICE v0.2: utilidades financieras DETERMINISTAS.
No estima datos faltantes, no decide el precio comercial; Decimal para dinero.
"""
from __future__ import annotations
from decimal import Decimal
from typing import Mapping, Optional, Sequence

DEFAULT_WEIGHTS = {
    'problem': Decimal('0.20'), 'impact': Decimal('0.20'),
    'strategic_fit': Decimal('0.15'), 'feasibility': Decimal('0.15'),
    'adoption': Decimal('0.15'), 'differentiation': Decimal('0.15')
}

def D(value):
    return Decimal(str(value))

def opportunity_score(scores: Mapping[str, Optional[int]], weights=DEFAULT_WEIGHTS):
    """Returns partial/full score and weighted criteria coverage. Null != zero."""
    if abs(sum(weights.values()) - D(1)) > D('0.0000001'):
        raise ValueError('Weights must sum to 1')
    numerator, observed_weight = D(0), D(0)
    for key, w in weights.items():
        v = scores.get(key)
        if v is None:
            continue
        if not isinstance(v, int) or isinstance(v, bool) or not (0 <= v <= 5):
            raise ValueError(f'{key} requires an integer 0..5 or None')
        numerator += w * D(v)/D(5)
        observed_weight += w
    if observed_weight == 0:
        return {'score': None, 'coverage_weight': D(0), 'provisional': True}
    return {'score': D(100)*numerator/observed_weight,
            'coverage_weight': observed_weight, 'provisional': observed_weight < 1}

def npv(initial_investment, monthly_cash_flows: Sequence, monthly_discount_rate):
    rate = D(monthly_discount_rate)
    if rate <= -1: raise ValueError('monthly discount rate must exceed -100%')
    return -D(initial_investment) + sum((D(x)/(D(1)+rate)**t for t,x in enumerate(monthly_cash_flows, start=1)),D(0))

def payback_months(initial_investment, monthly_cash_flows: Sequence):
    """First integer month with cumulative cashflow >= 0, otherwise None.
    No interpolation: the period is the first fully recovered month.
    """
    cumulative=-D(initial_investment)
    if cumulative >= 0: return 0
    for month, flow in enumerate(monthly_cash_flows, start=1):
        cumulative+=D(flow)
        if cumulative >= 0: return month
    return None

def gross_margin_price(cost, target_margin):
    margin=D(target_margin)
    if not 0 <= margin < 1: raise ValueError('0 <= target_margin < 1')
    if D(cost) < 0: raise ValueError('nonnegative cost required')
    return D(cost)/(D(1)-margin)

def contribution_delta(visits_with, conversion_with, visits_bau, conversion_bau, qualified, closing, contribution_per_sale):
    """Conversion inputs must be rates 0..1; results are expected contributions, not discrete actual sales."""
    for n,v in {'conversion_with':conversion_with,'conversion_bau':conversion_bau,'qualified':qualified,'closing':closing}.items():
        if not 0 <= D(v) <= 1: raise ValueError(f'{n} needs probability 0..1')
    sales_new=D(visits_with)*D(conversion_with)*D(qualified)*D(closing)
    sales_bau=D(visits_bau)*D(conversion_bau)*D(qualified)*D(closing)
    return (sales_new-sales_bau)*D(contribution_per_sale)

def hours_released(volume, minutes_saved_per_task):
    if D(volume)<0 or D(minutes_saved_per_task)<0: raise ValueError('nonnegative required')
    return D(volume)*D(minutes_saved_per_task)/D(60)

def captured_capacity_value(hours, capture_rate=None, economic_value_per_hour=None):
    """Unknown rate or cash value yields None rather than fictional savings."""
    if capture_rate is None or economic_value_per_hour is None: return None
    if not 0 <= D(capture_rate) <= 1: raise ValueError('capture rate must be 0..1')
    return D(hours)*D(capture_rate)*D(economic_value_per_hour)

if __name__ == '__main__':
    s=opportunity_score({'problem':4,'impact':4,'strategic_fit':3,'feasibility':3,'adoption':2,'differentiation':3})
    print('Ejemplo score (HEURISTICO)',s)
    print('VAN ejemplo',npv('2400',['550']*12,'0.01'))
    print('Payback mes',payback_months('2400',['550']*12))
    print('Precio piso de costo S/1800, margen35%',gross_margin_price('1800','0.35'))
