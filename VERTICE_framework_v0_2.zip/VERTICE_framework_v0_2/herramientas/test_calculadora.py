import unittest
from decimal import Decimal
from vertice_calc import opportunity_score,npv,payback_months,gross_margin_price,contribution_delta,hours_released,captured_capacity_value

class TestVertice(unittest.TestCase):
    def test_score_maximum(self):
        z=opportunity_score({x:5 for x in ('problem','impact','strategic_fit','feasibility','adoption','differentiation')})
        self.assertEqual(z['score'],Decimal('100'))
        self.assertFalse(z['provisional'])
    def test_unknown_not_zero(self):
        z=opportunity_score({'problem':5})
        self.assertEqual(z['score'],Decimal('100'))
        self.assertTrue(z['provisional'])
        self.assertEqual(z['coverage_weight'],Decimal('0.20'))
    def test_unknown_everywhere(self):
        self.assertIsNone(opportunity_score({})['score'])
    def test_margin(self):
        self.assertAlmostEqual(float(gross_margin_price(1800,'.35')),2769.23076923,places=3)
    def test_npv(self):
        self.assertEqual(npv(100,[60,60],0),Decimal(20))
    def test_payback(self):
        self.assertEqual(payback_months(100,[20,50,40]),3)
        self.assertIsNone(payback_months(100,[20,30]))
    def test_sales_delta(self):
        self.assertEqual(contribution_delta(1000,'.03',1000,'.02','1','.5',200),Decimal(1000))
    def test_freed_not_cash(self):
        self.assertEqual(hours_released(10,30),Decimal(5))
        self.assertIsNone(captured_capacity_value(5))
        self.assertEqual(captured_capacity_value(5,'.4',20),Decimal(40))
if __name__ == '__main__': unittest.main()
