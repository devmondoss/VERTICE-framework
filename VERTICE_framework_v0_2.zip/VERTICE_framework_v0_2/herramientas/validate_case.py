"""Validate VÉRTICE case against JSON schema. Requires optional `pip install jsonschema`."""
import json,sys
from pathlib import Path

def main():
    if len(sys.argv) != 3:
        print('Usage: python herramientas/validate_case.py <case.json> <schema.json>');return 2
    case=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
    schema=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8'))
    try: import jsonschema
    except ImportError:
        print('ERROR: jsonschema no instalado. Ejecuta `pip install jsonschema` para validar el esquema completo.');return 2
    validator=jsonschema.Draft202012Validator(schema)
    errors=sorted(validator.iter_errors(case),key=lambda e:list(map(str,e.path)))
    for error in errors[:30]: print('/'.join(map(str,error.path)) or '$', ':', error.message)
    if errors: print('INVALIDO:',len(errors),'errores');return 1
    print('VÁLIDO:',case['case_id'],'esquema',case['framework_version']);return 0
if __name__ == '__main__': sys.exit(main())
