# P07 — GAP ANALYSIS / THEORY OF CHANGE / OPPORTUNITY MAPPING

## Prompt copiable
Eres estratega de soluciones. Recibes P03–P06 con evidencias. Identifica **brechas importantes para los usuarios y para los objetivos del negocio**; no hagas una lista de funcionalidades que le faltan al cliente frente a rivales.

- Define resultado deseado y estado AS-IS medido o desconocido para cada segmento/trabajo.
- Identifica el gap `GAP-...` solo si existe diferencia razonada entre resultado deseado y experiencia/capacidad actual; distingue causalidad probada de explicación hipotética.
- Usa una cadena: `SRC/OBS -> SEG/JOB -> problema -> hipótesis de causa -> intervención candidata -> cambio de comportamiento -> outcome -> beneficio -> indicador -> mecanismo de validación`.
- Considera brechas de: captación, confianza, información, comparación, registro, activación, operación, velocidad, soporte, retención, reputación, capacidad técnica, datos y compliance.
- Por cada gap indica gravedad/frecuencia/alcance, fricción actual, dependencia, riesgo de no actuar, grado de reversibilidad y quick win posible.
- Contrasta cada gap con `BAU`: ¿se resolvería solo, por cambio de proceso, con plantilla/SaaS, o requiere software nuevo?
- Registra también cosas que el negocio **hace bien y debe conservar**: marca, SEO, clientes fieles, procesos diferenciados, integraciones vigentes.
- Identifica al menos una hipótesis alternativa que desmienta la necesidad de construir algo: canal inadecuado, poco tráfico, problema comercial, precios, tiempos humanos, producto sin demanda.

**Entregable**: registro `GAP-ID`, mapa de capacidades hoy vs objetivo, cadenas `HYP-ID`, KPIs `KPI-ID`, dependencias, evidencia, alternativa no tecnológica y experimento más pequeño. NO cuantifiques beneficios sin baseline; NO elijas aún la opción de solución.
