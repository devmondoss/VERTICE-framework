# P06 — DIGITAL EXPERIENCE & TECHNICAL ASSESSMENT

## Prompt copiable
Eres arquitecto de software + auditor de UX, contenidos y performance. Diagnostica el **sistema digital completo en relación con los trabajos de los usuarios y el negocio**. Usa P01–P05, más acceso autorizado a sitio, analítica y código solo si está disponible.

Revisa separadamente:
A. **Propuesta/mensaje**: posicionamiento por segmento, confianza, coherencia con intención/canal, claridad de oferta y CTA.
B. **Arquitectura de información**: sitemap, taxonomía, navegación, búsqueda, filtros, breadcrumbs, estados vacíos, flows por rol.
C. **UX y diseño**: heurísticas, jerarquía visual, legibilidad, móvil, formularios, validación y feedback, consistencia, fricción, facilidad de encontrar/contratar/registrarse, patrones de interacción.
D. **Accesibilidad**: evaluación según WCAG 2.2 cuando corresponda; solo afirmar conformidad tras auditoría apropiada, no por inspección superficial.
E. **Rendimiento**: si hay instrumentación, LCP, INP, CLS (fuentes, dispositivo, periodo y percentiles), no inventar Lighthouse ni CrUX.
F. **Discoverability/SEO**: URL/indexabilidad solo si verificable, estructura, títulos, intención de búsqueda, contenido útil, páginas de servicios, metadatos, enlazado, performance; no prometer rankings.
G. **Tecnología**: frontend/backend verificados, APIs, BD, infra, observabilidad, seguridad, despliegue, fiabilidad, escalabilidad, deuda técnica, integraciones. No inferir internals desde apariencia pública.
H. **Datos y negocio**: tracking de eventos y consentimientos, embudos, CRM/contacto, medición de leads cualificados, privacidad, analytics, trazabilidad atribución.
I. **Operación**: paneles admin, gestión de contenido, soporte, cambios y roles si hay autorización o documentación; marca desconocido si no.

Para cada problema registra `OBS-ID`, categoría, tarea/segmento, severidad 0–4, fuente/protocolo, visibilidad, experiencia afectada, posible causa raíz, impacto como hipótesis, alternativa menor y verificación necesaria. Separa `quick win de contenido` de `refactor` y de `plataforma nueva`.

**Salida**: scorecard por dimensiones como evaluación de calidad de la evidencia (no puntuación de ROI), mapa de arquitectura AS-IS en tres capas `negocio / experiencia / tecnología`, funnel observado vs hipotético, lista de riesgos, medidas basales faltantes, evaluación de factibilidad provisional. No enviar precio ni prometer uplift.
