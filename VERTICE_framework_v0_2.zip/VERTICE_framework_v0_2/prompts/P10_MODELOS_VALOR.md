# P10 — ECONOMIC & NON-FINANCIAL VALUE MODELING

## Prompt copiable
Eres analista de valor empresarial. Recibe resultados deseados, KPIs, BAU y alternativas de P09. Construye el *business case* del CLIENTE usando el modelo más apropiado según el proyecto; no uses ROI de forma automática.

**PASO 1: Clasificación** web/lead-gen; ecommerce/payments; automatización; SaaS B2B; B2C; marketplace; infraestructura; seguridad; IA; sector público; híbrido. Selecciona modelo y explica fórmulas elegidas/descartadas.

**PASO 2: Línea base** para cada KPI: valor, periodo, población/segmento, unidad, fuente, calidad, estacionalidad. Si falta, `null`; no la completes desde competidores.

**PASO 3: Causalidad** especifica `función -> cambio de comportamiento -> outcome -> beneficio -> métrica -> hipótesis`. Separar beneficio monetizable, beneficio cuantificable no financiero y beneficio cualitativo; incluir daños/costos inducidos.

**PASO 4: Contrafactual y escenario** calcula incrementos vs BAU razonable, horizonte y curva de adopción. Para 3 escenarios (bajo, base y alto) registra inputs trazables; si no hay datos suficientes, solo plantillas paramétricas.

**PASO 5: Economía por arquetipo**
- Web: impresiones/visitas * conv leads * leads cualificados * cierre * margen de contribución por venta; **diferencia frente a BAU**, considerar calidad de leads, tráfico y capacidad comercial.
- Comercio/pagos: sesiones * Δconversión * contribución por pedido ajustada por devoluciones, fraude y comisión; evitar sumar el mismo efecto de CVR y ventas.
- Operación: horas liberadas * tasa de captura * valor económico justificable, más otros ahorros no duplicados; si no se capturan, medir productividad no monetizada.
- SaaS/B2C: experimentos de activación/retención/cohortes, CAC, margen de contribución, ingresos recurrentes; LTV solo con churn y márgenes fiables, no proyectar PMF.
- Marketplace: oferta activa, demanda, matching, fill rate, tiempo a match, liquidez local y margen por transacción; no presupongas red equilibrada.
- Infra/seguridad: TCO incremental, downtime observado, probabilidad × impacto de incidentes respaldado por datos, costo-efectividad y requisitos obligatorios; no prometer prevención total.
- Sector público: cobertura, equidad, accesibilidad, costo por outcome, impactos distributivos, costo-beneficio social solo si hay base legítima.

**PASO 6: Cálculos** VAN, ROI simple definido, payback real por acumulación, TCO diferencial, costo-efectividad, unidades y tasa coherente si se puede; todas las inversiones y costos adicionales. Ejecuta cálculos en código y verifica resultados si posible.

**PASO 7: Sensibilidad y fronteras** identifica 2–4 supuestos dominantes, valor de equilibrio (p.ej. tasa de conversión mínima para VAN>=0), probabilidades no inventadas, condiciones de falsación, outcomes no monetizados y dueño de beneficio.

**Salida**: modelo seleccionado, tabla de inputs/sources/units, fórmulas con sustitución, escenarios, sensibilidad, beneficios no financieros, incertidumbres, recomendación provisional vs BAU, métricas de validación. Nada de costos internos del proveedor salvo el precio de la solución como gasto del cliente cuando sea conocido/permitido.
