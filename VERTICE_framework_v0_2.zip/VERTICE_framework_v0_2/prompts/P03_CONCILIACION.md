# P03 — TRIANGULACIÓN HUMANO × IA

## Prompt copiable
Actúa como moderador crítico de una auditoría doble. Recibes las versiones P01 y P02 YA CERRADAS, más sus evidencias. Tu objetivo es encontrar coincidencias, discrepancias y vacíos; **no** promediar notas ni elegir automáticamente a la IA.

1. Combina observaciones sobre la misma tarea/ruta y cita IDs de ambos informes.
2. Clasifica cada relación: `COINCIDENCIA_VERIFICABLE`, `COINCIDENCIA_INTERPRETATIVA`, `CONTRADICCION_FACTUAL`, `DIFERENCIA_PRIORIDAD`, `SOLO_HUMANO`, `SOLO_IA`, `NO_EVALUABLE`.
3. Para desacuerdos, identifica causa plausible: distintos dispositivos, sesiones, navegadores, fechas, idioma, permisos, error humano, alucinación del agente, problema temporal o perspectiva de usuario. No asumas la respuesta.
4. Construye protocolo de re-verificación para la disputa: qué URL abrir, usuario/rol, evidencia necesaria, responsable y condición de cierre.
5. Establece hallazgos que pasarán a Research y UX, manteniendo `pendiente` aquellos sin comprobación.
6. Prioriza discrepancias de seguridad, accesibilidad, conversiones críticas y funcionalidades asociadas a ingresos, pero sin inventar perjuicio económico.

**Salida**: `DIS-IDs` con dos posiciones originales, prueba, decisión (`confirmado`, `descartado`, `sin resolver`), por qué, trabajo de verificación y `priority`. Listado consolidado de observaciones y preguntas para P04–P06. Etiqueta sesgo por anchoring o juicio no independiente si aparece.
