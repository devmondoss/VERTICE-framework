# P05 — ICP / JOBS TO BE DONE / USER JOURNEYS / ACQUISITION FIT

## Prompt copiable
Eres estratega de producto e investigador UX. Tus insumos son `CASE_BRIEF`, reconciliación P03 y Deep Research P04. Analiza **para quién existe valor**, qué intenta hacer esa persona y qué experiencia debería corresponder a su intención. No conviertas perfiles inventados en estudios de mercado.

1. Lista stakeholders por separado: quien descubre, usa, compra/paga, decide, aprueba, recomienda, implementa y da soporte. En B2B existe comité de compra; en marketplaces, demanda y oferta pueden tener journeys diferentes; en B2C compradores y usuarios pueden o no coincidir.
2. Para cada `SEG-ID` construye un perfil de cliente ideal **hipotético**: contexto, desencadenante, JTBD funcional/emocional/social, frecuencia, riesgo percibido, criterio de elección, objeciones, canal y oferta relevante. Cada afirmación lleva evidencia `SRC` o `hipótesis`.
3. Define jobs observables: `Cuando [situación], necesito [progreso], para [resultado]`. Evita personas caricaturizadas e información demográfica irrelevante.
4. Esquematiza journeys AS-IS por tareas prioritarias: descubrimiento → evaluación → confianza → conversión/registro → activación → obtención del resultado → retención/recomendación. En cada etapa: touchpoint, acción, expectativa, información, fricción, emoción solo si usuario lo reportó, KPI y dato necesario.
5. Relaciona canales e intención: búsqueda informativa vs comercial vs transaccional vs marca; referencia, SEO, ads, social, email, partners y directo si existen datos. No atribuyas una fuente de tráfico sin analítica.
6. Evalúa message–market fit y message–landing fit: promesa, señal de credibilidad, CTA adecuado, formulario mínimo, dudas, expectativas y seguimiento. En un canal de pago no midas solo clicks: conversión cualificada, CAC/CPA y posterior activación si hay datos.
7. Define arquitectura de información/sitemap y user flows candidatos por segmento; **son hipótesis de diseño**, no decisión final.
8. Si no hay usuarios entrevistados, prepara guía de investigación: 5–8 preguntas sobre comportamiento reciente (no «¿te gustaría?»), top tasks, guion de prueba de tareas con éxito, tiempo y fricciones; no afirmes que fue ejecutada.
9. Considera accesibilidad, diversidad de habilidades, contexto móvil, idioma y conectividad cuando relevantes; no atribuyas características personales a usuarios no investigados.

**Salida obligatoria**: tabla de `SEG-ID` y `JOB-ID` con grado de evidencia, `JRN-ID` AS-IS y futuro marcado como hipotético, matriz de `canal × intención × contenido × CTA × KPI`, sitemap y flujos a validar, plan breve de entrevistas/tests, prioridades de problema; handoff a P06/P07.
