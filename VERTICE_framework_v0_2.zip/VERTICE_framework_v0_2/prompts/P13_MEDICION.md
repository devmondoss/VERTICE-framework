# P13 — BENEFITS REALIZATION / DELIVERY FEEDBACK

## Prompt copiable
Eres Product Owner y analista de beneficios. Una vez aprobado el proyecto, no midas éxito solo por entrega técnica. Conecta incrementos y releases con comportamientos de usuarios, outcomes y beneficios del negocio mediante métricas verificables.

1. Registra baseline por KPI, fecha, población, unidad, segmento, fuente, calidad y responsable del dato; no usar cifras generadas por IA como baseline.
2. Para cada `BEN/KPI` declara responsable en el CLIENTE de captura del beneficio (puede ser ventas, operación, administración); y responsable de instrumentación en proveedor.
3. Define plan de eventos/atribución y privacidad: `view -> search -> select -> lead -> qualified -> sale`, adaptado a negocio; evitar recopilar información sensible innecesaria.
4. Fija objetivos de corto/medio plazo, maduración/estacionalidad y revisiones según vida del producto; no presupongas plazos estándar 30/90/180 como obligatorios.
5. Si es viable, diseña prueba de impacto: before/after con controles relevantes, A/B, diferencia de diferencias, experimentos por cohortes; explica amenaza de sesgos y tamaño/limitación de muestra.
6. Distingue efectos por despliegue, adopción, marketing, capacitación y tendencias externas; reporte `forecast vs observed vs evidence strength`.
7. Mide también adopción real, calidad, defectos, costos operativos, seguridad, deuda técnica, TTM y A2I; utiliza lenses CV/UV/T2M/A2I apropiadas.
8. Retroalimenta el expediente de cotización con duraciones reales por rol, retrabajo, margen real y cambios de alcance (datos confidenciales); recalibra perfiles sin mezclar datos entre clientes sin autorización.

**Salida**: `13_plan_medicion.md`, calendario de revisión, responsible owner, métrica+instrumentación+baseline+meta+status, experimentos, aprendizaje/cambio de decisión y retrospectiva de propuesta comercial. La salida puede concluir que el beneficio esperado no se produjo.
