# P01 — AUDITORÍA HUMANA (ingeniero / consultor)

## Instrucciones para el humano, no ejecutar como reemplazo de observación
Examinar personalmente el sitio/producto con un brief neutral de P00. **No leer la futura auditoría del modelo** hasta registrar tu versión. Navegar tareas reales, diferentes roles y, si aporta, móvil y escritorio. Documentar hechos con URL/capturas propias permitidas.

**Checklist por tarea**: qué quiere conseguir el usuario, ruta seguida, clics/etapas aproximadas, información necesaria, expectativa, barrera observada, posibilidad de completar, CTA y resultado. Registrar si tarea se pudo verificar o si requiere login/datos no accesibles.

**Capas de revisión**:
- Claridad de promesa: ¿se entiende para quién es, qué ofrece y por qué confiar?
- Arquitectura de información: sitemap, navegación, agrupación de categorías, búsqueda y filtros.
- UX y diseño: claridad visual, jerarquía, feedback, error, formularios, responsividad observada.
- Conversión: canal/intención/landing/CTA/registro/contacto; si no hay analítica no atribuir pérdidas medibles.
- Técnica: rendimiento percibido (NO puntuar LCP sin medida), SEO visible, estructura, integraciones visibles; stack desconocido cuando no verificable.
- Privacidad/confianza: testimonios verificables, políticas, contenido y accesibilidad observables.
- Negocio: segmentos que no encuentran una vía clara; oferta faltante solo como hipótesis, no como hecho.

**Para cada hallazgo** registrar `OBS-H-ID`, task, URL/ruta, viewport, reproducibilidad, descripción factual, interpretación, severidad 0–4 justificada, evidencia, riesgo e incertidumbre, recomendación preliminar que NO presuponga desarrollo. Diferenciar `observé que no aparece` de `no existe`. Guardar notas antes de que P02 se comparta.

**Entregable**: `01_auditoria_humana.md` con portada, tabla de tareas, observaciones por categorías, mapa provisional de flujo actual AS-IS, hipótesis, vacíos, dudas técnicas, nivel de severidad y sello temporal. Sin ROI y sin comparación con el agente.
