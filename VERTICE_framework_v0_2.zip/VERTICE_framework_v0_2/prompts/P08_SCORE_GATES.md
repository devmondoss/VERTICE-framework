# P08 — QUALIFICATION / SCORING / EVIDENCE GATES

## Prompt copiable
Eres miembro del comité de calificación de oportunidades. Evalúa las oportunidades P07 y su evidencia, manteniendo **puntuación de oportunidad** independiente de **calidad de evidencia**, **riesgo** y **atractivo comercial para nuestra consultora**.

1. Selecciona y congela antes de puntuar un perfil de pesos apropiado (default VÉRTICE: problema 20%; impacto 20%; alineación 15%; viabilidad 15%; adopción 15%; diferenciación 15%) y versión. Personalización solo con justificación previa.
2. Puntúa cada criterio 0–5 con justificación y evidencia; `null` si desconocido. Indica cobertura y si hay variable crítica desconocida. No reportes como `0` lo desconocido.
3. Usa fórmula `100 * Σ(w_i*s_i/5) / Σ(w_i disponibles)` solo para **puntaje parcial**; bloquea ranking concluyente entre proyectos cuando faltan criterios críticos. Los valores no equivalen a probabilidad de éxito.
4. Grade de evidencia por claim crítico A/B/C/D/U y cobertura A+B; advertir si fuentes no son independientes. A no significa que el efecto futuro esté garantizado.
5. Aplica gates: riesgo de privacidad/seguridad/regulación, necesidad del usuario, disponibilidad del dato, dependencia/permiso del tercero, factibilidad de equipo, presupuesto/estrategia, irreversibilidad.
6. Prioriza decisión de aprendizaje: entrevista, analítica, test UX, experimento de canal, prototipo, smoke test, piloto pagado o PoC técnica; cada acción debe contestar una pregunta que podría cambiar la decisión.
7. Determina estado `INVESTIGAR`, `EXPERIMENTAR`, `PASAR_A_OPCIONES`, `REPLANTEAR` o `DESCARTAR`. Puede haber varias oportunidades y solo algunas pasan.

**Salida**: tabla scorecard por `OPP-ID` (seis valores, pesos, score provisional, cobertura, riesgos y status); 3 incógnitas materiales; experimentos de validación y costo/tiempo SOLO si hay datos; explicación de por qué pasa o no pasa. No diseñes cotización todavía.
